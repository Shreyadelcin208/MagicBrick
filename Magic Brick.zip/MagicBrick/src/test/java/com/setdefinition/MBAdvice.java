package com.setdefinition;

import java.time.Duration;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class MBAdvice {

    private WebDriver driver;
    private WebDriverWait wait;

    @Given("the user is on the shortlist page")
    public void userIsOnShortlistPage() {
        // Corrected line to setup ChromeDriver using WebDriverManager
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(15)); // Initializing WebDriverWait
        driver.get("https://www.magicbricks.com/");
        driver.manage().window().maximize();
    }

    @When("the user clicks on {string}")
    public void userClicksOn(String menu) {
        By locator;

        // Note: I have added a comment here as 'Home Loan' and 'MB Advice' have the same XPath.
        // Please verify the correct locators for each if they are different.
        switch (menu) {
            case "Home Loans":
                locator = By.xpath("//*[@id='shortlistWeb']/div[1]/div/div/div[1]/div[5]/div/div/div/ul/li[1]/a");
                break;
            case "Home Loan":
            case "MB Advice": // Both have the same locator in your original code. Verify this.
                locator = By.xpath("/html/body/header/section[2]/div/ul/li[6]/a");
                break;
            case "Insights":
                locator = By.xpath("/html/body/header/section[2]/div/ul/li[6]/div/div/div[1]/ul/li[1]/a");
                break;
            case "PropIndex":
                locator = By.xpath("//*[@id='card-anchor']/div/a[2]");
                break;
            case "View Report":
                locator = By.xpath("//*[@id='report-list']/div/div/article/section/footer/a[1]");
                break;
            case "Submit":
                locator = By.xpath("//*[@id='form1']/button");
                break;
            case "Verify":
                locator = By.xpath("//*[@id='otpSection']/button");
                break;
            default:
                throw new IllegalArgumentException("Unknown menu item: " + menu);
        }

        // Using explicit wait to ensure the element is clickable before clicking
        wait.until(ExpectedConditions.elementToBeClickable(locator)).click();
    }

    @And("the user selects the city as {string}")
    public void selectCity(String city) {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='select2-filter-city-container']"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(text(),'" + city + "')]"))).click();
    }

    @And("the user selects the quarter as {string}")
    public void selectQuarter(String quarter) {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='select2-filter-quarter-container']"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(text(),'" + quarter + "')]"))).click();
    }

    @And("the user selects the year as {string}")
    public void selectYear(String year) {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='select2-filter-year-container']"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(text(),'" + year + "')]"))).click();
    }

    @And("the user enters the following details:")
    public void enterUserDetails(DataTable dataTable) {
        List<Map<String, String>> data = dataTable.asMaps(String.class, String.class);
        Map<String, String> user = data.get(0);

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='Name']"))).sendKeys(user.get("Name"));
        driver.findElement(By.xpath("//*[@id='Email']")).sendKeys(user.get("Email"));
        driver.findElement(By.xpath("//*[@id='Mobile']")).sendKeys(user.get("Mobile"));
        driver.findElement(By.xpath("//*[@id='company']")).sendKeys(user.get("Company"));
        driver.findElement(By.xpath("//*[@id='cityInput']")).sendKeys(user.get("City"));
    }

    @And("the user enters the OTP as {string}")
    public void enterOTP(String otp) {
        // Assuming the OTP input field has an ID like 'otpInput'.
        // Replace with the actual ID or XPath of the OTP input field on the page.
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("otpInput"))).sendKeys(otp);
    }

    @Then("the user should be able to download the report")
    public void downloadReport() {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='report-list']/div/div/article/section/footer/a[2]/img"))).click();
        driver.quit();
    }
}