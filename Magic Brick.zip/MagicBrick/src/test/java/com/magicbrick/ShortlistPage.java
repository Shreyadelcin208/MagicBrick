package com.magicbrick;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ShortlistPage {
    WebDriver driver;

    public ShortlistPage(WebDriver driver) {
        this.driver = driver;
    }

    public void open() {
        driver.get("https://www.magicbricks.com/shortlist");
        System.out.println("Opened Shortlist Page.");
    }

    public void clickHomeLoans() {
        driver.findElement(By.linkText("Home Loans")).click();
        System.out.println("Clicked Home Loans.");
    }
}
