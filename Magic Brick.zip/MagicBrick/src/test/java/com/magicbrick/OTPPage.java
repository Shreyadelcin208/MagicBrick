package com.magicbrick;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class OTPPage {
    WebDriver driver;

    public OTPPage(WebDriver driver) {
        this.driver = driver;
    }

    public void enterOTP(String otp) {
        driver.findElement(By.id("otp")).sendKeys(otp);
        System.out.println("Entered OTP.");
    }

    public void clickVerify() {
        driver.findElement(By.xpath("//button[contains(text(),'Verify')]")).click();
        System.out.println("Clicked Verify.");
    }

    public boolean isDownloadButtonVisible() {
        return driver.findElement(By.id("downloadBtn")).isDisplayed();
    }
}
