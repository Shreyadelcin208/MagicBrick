package com.magicbrick;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager; // <-- Add this import

@Test
public class DownloadPropIndexTest {
    WebDriver driver;

    @BeforeClass
    public void setup() {
        // CORRECTED: Call the static method on the WebDriverManager class
        WebDriverManager.chromedriver().setup(); 
        
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
    }

    public void testDownloadPropIndexReport() {
        // Page objects
        ShortlistPage shortlistPage = new ShortlistPage(driver);
        HomeLoanPage homeLoansPage = new HomeLoanPage();
        MBAdvicePage mbAdvicePage = new MBAdvicePage(driver);
        InsightsPage insightsPage = new InsightsPage(driver);
        PropIndexPage propIndexPage = new PropIndexPage(driver);
        ReportPage reportFormPage = new ReportPage(driver);
        OTPPage otpPage = new OTPPage(driver);

        // Flow
        shortlistPage.open();
        shortlistPage.clickHomeLoans();
        homeLoansPage.navigateToHomeLoanPage();
        mbAdvicePage.clickInsights();
        insightsPage.clickPropIndex();

        propIndexPage.selectCity("Chennai");
        propIndexPage.selectQuarter("Q1");
        propIndexPage.selectYear("2023");
        propIndexPage.clickViewReport();

        reportFormPage.fillForm("John Tester", "john@test.com", "9876543210", "Test Company", "Chennai");
        reportFormPage.submitForm();

        otpPage.enterOTP("123456"); // Dummy OTP
        otpPage.clickVerify();

        AssertJUnit.assertTrue(otpPage.isDownloadButtonVisible());
        System.out.println("✅ Report download option is available!");
    }

    @AfterMethod
	@AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}