package com.magicbrick;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class MBAdvicePage {
    WebDriver driver;

    public MBAdvicePage(WebDriver driver) {
        this.driver = driver;
    }

    public void clickInsights() {
        driver.findElement(By.linkText("Insights")).click();
        System.out.println("Navigated to Insights.");
    }
}
