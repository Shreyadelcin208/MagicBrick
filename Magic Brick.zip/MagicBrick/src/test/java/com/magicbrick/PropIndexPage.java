package com.magicbrick;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class PropIndexPage {
    WebDriver driver;

    public PropIndexPage(WebDriver driver) {
        this.driver = driver;
    }

    public void selectCity(String city) {
        new Select(driver.findElement(By.id("cityDropdown"))).selectByVisibleText(city);
    }

    public void selectQuarter(String quarter) {
        new Select(driver.findElement(By.id("quarterDropdown"))).selectByVisibleText(quarter);
    }

    public void selectYear(String year) {
        new Select(driver.findElement(By.id("yearDropdown"))).selectByVisibleText(year);
    }

    public void clickViewReport() {
        driver.findElement(By.xpath("//button[contains(text(),'View Report')]")).click();
        System.out.println("Clicked View Report.");
    }
}
