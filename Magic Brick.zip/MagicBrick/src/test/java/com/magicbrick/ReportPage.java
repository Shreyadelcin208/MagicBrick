package com.magicbrick;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ReportPage {
    WebDriver driver;

    public ReportPage(WebDriver driver) {
        this.driver = driver;
    }

    public void fillForm(String name, String email, String mobile, String company, String city) {
        driver.findElement(By.id("name")).sendKeys(name);
        driver.findElement(By.id("email")).sendKeys(email);
        driver.findElement(By.id("mobile")).sendKeys(mobile);
        driver.findElement(By.id("company")).sendKeys(company);
        driver.findElement(By.id("city")).sendKeys(city);
        System.out.println("Form filled successfully.");
    }

    public void submitForm() {
        driver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
        System.out.println("Clicked Submit.");
    }
}
