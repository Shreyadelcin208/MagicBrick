 package com.objectrepository;

import org.openqa.selenium.By;

public class Locators {
	 public static By homeLoginBtn = By.xpath("//*[@id=\"commercialIndex\"]/header/section[1]/div/div[2]/div[2]/a");
	 public static By innerLoginBtn = By.xpath("//*[@id=\"commercialIndex\"]/header/section[1]/div/div[2]/div[2]/div/div[2]/a");
	 public static By googleLoginBtn = By.xpath("//*[@id=\"my-signin2\"]/div/div");
	 public static By phonenumber = By.xpath("//*[@id=\"emailOrMobile\"]");
	 public static By nextbtn = By.id("btnStep1");
	 public static By captacha = By.xpath("//*[@id=\"captchaCodeSignIn\"]");
	 public static By otp1 = By.id("verify01");
	 public static By otp2 = By.id("verify02");
	 public static By otp3 = By.id("verify03");
	 public static By otp4 = By.id("verify04");
     public static By continuebtn = By.xpath("//*[@id=\"verifyOtpDiv\"]/div[2]/div[3]/button");
     public static By closepopup = By.xpath("//*[@id=\"userOnboardingWidget\"]/div/div[1]");
     
     // for enter the location
   
     //public static By defaultLocation = By.xpath("//*[@id=\"commercialIndex\"]/header/section[1]/div/div[1]/div[2]/a");
     //public static By closedefault = By.xpath("//*[@id=\"commercialIndex\"]/header/section[1]/div/div[1]/div[2]/div/div[1]/div[3]/ul/li[4]/a");
     public static By enterlocation = By.id("keyword");
     
     // selecting propertytype
     public static By clearPropertyType = By.xpath("//*[@id=\"propType_buy\"]/div[2]/div/div/div[1]/div[2]/div[4]");
     public static By clickPropertType = By.id("propType_buy");
     public static By dropdownProperType = By.xpath("//*[@id=\"propType_buy\"]/div[1]");
     public static By selectPropertyType = By.id("10002_10003_10021_10022");
     public static By closePropertyType = By.xpath("//*[@id=\"buy_proertyTypeDefault\"]");
     
     //selecting budget
     public static By clickBudget = By.xpath("//*[@id=\"rent_budget_lbl\"]");
     public static By mindropdown=By.xpath("//*[@id=\"budgetMin\"]");
     public static By maxdropdown=By.xpath("//*[@id=\"budgetMax\"]");
     public static By closeBudget = By.xpath("//*[@id=\"rent_budget_lbl\"]");
     public static By searchButton = By.xpath("//*[@id=\"searchFormHolderSection\"]/section/div/div[1]/div[3]/div[4]");
     
     //sort property
     public static By sortBy = By.xpath("//*[@id=\"body\"]/div[5]/div/div/div[1]/div[1]/div[1]");
     public static By mostrecent = By.xpath("//*[@id=\"body\"]/div[5]/div/div/div[1]/div[1]/div/div[2]/ul/li[4]");
     
     //shortlist property
     public static By shortlistButton = By.xpath("//*[@id=\"cardid81313823\"]/div/div[1]/div[2]/span[2]");
     public static By mainshortlistbtn = By.xpath("//*[@id=\"propertysrp\"]/div[1]/div/div/div[2]/div[5]/span");
     public static By viewShortlistBtn = By.xpath("//*[@id=\"propertysrp\"]/div[1]/div/div/div[2]/div[5]/div/div/a");
     public static By shortlistedPropertyCard = By.xpath("//*[@id=\"cardid81313823\"]/div[2]");
     public static By shortlistTabHeader = By.xpath("//*[@id=\"m-tab-Shortlisted\"]");
     
     public static By viewDetailsButton = By.xpath("//*[@id=\"more-details\"]/div[2]/div[1]/a");
     public static By shortlistButton1 = By.xpath("//*[@id=\"shortlistWeb\"]/div[1]/div/div/div[1]/div[5]/span");
     public static By homeLoans = By.xpath("//*[@id=\"propertyDetail\"]/div[2]/div/div/div[1]/div[5]");
     public static By homeLoan = By.xpath("/html/body/header/section[2]/div/ul/li[6]/a");
     public static By mbAdvice = By.xpath("/html/body/header/section[2]/div/ul/li[6]/a");
     public static By insight = By.xpath("/html/body/header/section[2]/div/ul/li[6]/div/div/div[1]/ul/li[1]/a");
     public static By propIndex = By.xpath("//*[@id='card-anchor']/div/a[2]");
     public static By cityDropdown = By.xpath("//*[@id='select2-filter-city-container']");
     public static By quarterDropdown = By.xpath("//*[@id='select2-filter-quarter-container']");
     public static By yearDropdown = By.xpath("//*[@id='select2-filter-year-container']");
     public static By firstArticleImage = By.xpath("//*[@id='report-list']/div[1]/div/article/figure/img");
     public static By viewreport = By.xpath("//*[@id=\"report-list\"]/div/div/article/section/footer/a[1]");
     public static By nameField = By.xpath("//*[@id='Name']");
     public static By emailField = By.xpath("//*[@id='Email']");
     public static By mobileNumberField = By.xpath("//*[@id='Mobile']");
     public static By companyNameField = By.xpath("//*[@id='company']");
     public static By cityField = By.xpath("//*[@id='cityInput']");
     public static By selectButton = By.xpath("//*[@id='form1']/button");
     public static By otp = By.xpath("verify");
     public static By verification = By.xpath("//*[@id=\"otpSection\"]/button");
     public static By downloadreport  = By.xpath("//*[@id=\"report-list\"]/div/div/article/section/footer/a[2]/img");
     

    
     
    
}