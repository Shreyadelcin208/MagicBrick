package com.magicbrick;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class HomeLoanPage {

    // IMPORTANT: These XPaths are very specific and may break with website updates.
    // They are used here as requested.
    public static By homeLoans = By.xpath("//*[@id=\"propertyDetail\"]/div[2]/div/div/div[1]/div[5]");
    public static By homeLoan = By.xpath("/html/body/header/section[2]/div/ul/li[6]/a");

    public static void main(String[] args) {
        // IMPORTANT: Set the path to your ChromeDriver executable.
        // Example for Windows: System.setProperty("webdriver.chrome.driver", "C:\\path\\to\\chromedriver.exe");
        // Example for macOS/Linux: System.setProperty("webdriver.chrome.driver", "/path/to/chromedriver");

        WebDriver driver = null;

        try {
            // Initialize the WebDriver
            driver = new ChromeDriver();
            driver.manage().window().maximize();

            // Navigate to the Magicbricks website
            driver.get("https://www.magicbricks.com/");

            // Set up an explicit wait with a 20-second timeout.
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

            // Step 1: Click on the first Home Loans element.
            System.out.println("Waiting for the first 'Home Loans' element to be clickable...");
            wait.until(ExpectedConditions.elementToBeClickable(homeLoans)).click();
            System.out.println("Successfully clicked the first 'Home Loans' element.");

            // Step 2: Click on the second Home Loan element.
            // This is a new click on a different element after the page state changes.
            System.out.println("Waiting for the second 'Home Loan' element to be clickable...");
            wait.until(ExpectedConditions.elementToBeClickable(homeLoan)).click();
            System.out.println("Successfully clicked the second 'Home Loan' element.");

        } catch (Exception e) {
            System.err.println("An error occurred during the test: " + e.getMessage());
        } finally {
            // Ensure the browser is closed after the test completes or fails.
            if (driver != null) {
                driver.quit();
            }
        }
    }

	public void navigateToHomeLoanPage() {
		// TODO Auto-generated method stub
		
	}
}