package com.magicbrick;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class InsightsPage {
    WebDriver driver;

    public InsightsPage(WebDriver driver) {
        this.driver = driver;
    }

    public void clickPropIndex() {
        driver.findElement(By.linkText("PropIndex")).click();
        System.out.println("Clicked PropIndex.");
    }
}
